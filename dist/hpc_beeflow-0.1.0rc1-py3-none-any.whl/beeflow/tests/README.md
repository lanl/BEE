# BEE Unit Testing
This directory shall be used for unit testing BEE modules for stability
and compatability across changes

The `workflows` directory contains sample workflow data in the form of CWL
files or pre-built Neo4j databases.

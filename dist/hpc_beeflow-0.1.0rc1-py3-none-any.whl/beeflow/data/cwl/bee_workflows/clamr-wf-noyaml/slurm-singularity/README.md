# CLAMR-FFMPEG WORKFLOW 

Using a Singularity container runtime, this workflow executes the `CLAMR` AMR simulation and then runs `ffmpeg` to produce a video from the `CLAMR` output.

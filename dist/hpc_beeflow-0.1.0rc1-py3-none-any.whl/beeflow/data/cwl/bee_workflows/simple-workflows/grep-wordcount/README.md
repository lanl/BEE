Simple example of a two step workflow.

gc.cwl -  A simple workflow that greps a file (lorem.txt) for a value, using a container.
gc-nc.cwl - A simple workflow that greps a file (lorem.txt) for a value, no container.

# Validating CWL behavior

Working from CWL v1.1. It's often useful to test the CWL expected behavior by validating with CWL tool, ie- `cwltool --validate <my file>`. This directory is a home for all CWL tool validations which are not explicitly designed to run on BEE. These CWL examples are not designed to demonstrated the funcitonality of BEE, but to demonstrate the expected behavior of the CWL reference implementation.

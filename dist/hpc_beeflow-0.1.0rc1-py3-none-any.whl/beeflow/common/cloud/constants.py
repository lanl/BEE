"""Cloud constants."""


BEE_USER = 'bee'

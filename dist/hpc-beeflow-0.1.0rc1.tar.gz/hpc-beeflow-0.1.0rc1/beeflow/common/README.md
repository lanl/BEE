# BEE Common
The common directory contains all of the software shared by the BEE client
and server. Most (all?) of this software is intended to be classes imported
into other tools and is not expected to run in a standalone fashion.


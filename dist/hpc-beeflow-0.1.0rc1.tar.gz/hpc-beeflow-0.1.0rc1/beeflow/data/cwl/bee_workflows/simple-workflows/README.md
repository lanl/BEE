Simple Workflows:

Files:  
* `cancel.cwl`: A workflow which sleeps for 20 seconds, long enough to demonstrate the cancel functionality BEE provides.


Directories: 
* `grep-wordcount/`: A workflow which parses an input file (`lorem.txt`) and counts the number of lines which contain the literal string "`integer`".


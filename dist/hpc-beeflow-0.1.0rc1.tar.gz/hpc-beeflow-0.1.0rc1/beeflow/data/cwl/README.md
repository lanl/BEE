# CWL files

This directory is home to CWL files. These may be in JSON or YAML format. 

* `bee_workflow` directory: Workflows which are designed to run with BEE.
* `cwl_validation` directory:  Workflows which are used to validate cwl behavior, but are not explicitly expected to run with BEE.
* `synthetic` directory:  Exampes of CWL code, features and cwl files, that can be used for testing or experimentation.

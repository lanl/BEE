# BEE Client
The client directory contains all of the client-only software necessary
to launch and monitor BEE workflows.
